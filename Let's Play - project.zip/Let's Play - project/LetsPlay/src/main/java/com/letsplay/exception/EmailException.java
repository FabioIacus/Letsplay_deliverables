package com.letsplay.exception;

public class EmailException extends Exception {
    public EmailException(String message) {
        super(message);
    }
}
