package com.letsplay.exception;

public class UsernameException extends RuntimeException {
    public UsernameException(String message) {
        super(message);
    }
}
