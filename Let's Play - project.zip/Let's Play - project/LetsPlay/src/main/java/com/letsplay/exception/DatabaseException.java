package com.letsplay.exception;

public class DatabaseException extends Exception {
    public DatabaseException(String message) {
        super(message);
    }
}
