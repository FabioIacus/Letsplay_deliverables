package com.letsplay.controller;
import javafx.fxml.FXML;
import javafx.scene.layout.BorderPane;

public class Homepage {

    public class PleaseProvideControllerClassName {

        @FXML
        private BorderPane centrale;

    }

}
