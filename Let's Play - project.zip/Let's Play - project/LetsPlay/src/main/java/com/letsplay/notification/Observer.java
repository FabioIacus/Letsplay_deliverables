package com.letsplay.notification;

public interface Observer {
    public void update();
}
